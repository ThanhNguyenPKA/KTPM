create database qlbgx;
use qlbgx;

CREATE TABLE KhuVuc (
    MaKhuVuc VARCHAR(10) PRIMARY KEY,
    TenKhuVuc VARCHAR(100)
);

CREATE TABLE LoaiVe (
    MaVe VARCHAR(10) PRIMARY KEY,
    TenVe VARCHAR(100)
);

CREATE TABLE VeNgay (
    MaVe VARCHAR(10) PRIMARY KEY,
    LoaiXe VARCHAR(50),
    BienSo VARCHAR(50),
    MauXe VARCHAR(50),
    KhuVuc VARCHAR(10),
    ViTri VARCHAR(10),
    GioNhan TIME,
    NgayNhan DATE,
    NgayTra DATE,
    GioTra TIME
);

CREATE TABLE VeThang (
    MaVe VARCHAR(10) PRIMARY KEY,
    LoaiXe VARCHAR(50),
    BienSo VARCHAR(50),
    MauXe VARCHAR(50),
    TenKH VARCHAR(100),
    SoDienThoai VARCHAR(20),
    NgayDangKy DATE,
    GioNhan TIME,
    NgayNhan DATE,
    NgayTra DATE,
    GioTra TIME,
    ViTri VARCHAR(10),
    KhuVuc VARCHAR(10)
);

CREATE TABLE ViTri (
    MaViTri VARCHAR(10) PRIMARY KEY,
    TenViTri VARCHAR(100),
    MaKhuVuc VARCHAR(10)
);

INSERT INTO khuvuc (MaKhuVuc, TenKhuVuc) VALUES
('KV001', 'Khu Vuc 1'),
('KV002', 'Khu Vuc 2'),
('KV003', 'Khu Vuc 3'),
('KV004', 'Khu Vuc 4'),
('KV005', 'Khu Vuc 5'),
('KV006', 'Khu Vuc 6');

INSERT INTO loaive (MaVe, TenVe) VALUES
('L001', 'Vé Ngày'),
('L002', 'Vé Tháng');

INSERT INTO vengay (MaVe, LoaiXe, BienSo, MauXe, KhuVuc, ViTri, GioNhan, NgayNhan, NgayTra, GioTra)
VALUES
('VN0001', 'Xe Đạp', '30A-12311', 'red', 'KV004', 'VT004', '23:19:40', '2024-03-25', '1970-01-01', '00:00:00'),
('VN0002', 'Xe Đạp', '29V5-222', 'đen', 'KV002', 'VT002', '21:46:39', '2024-08-11', '1970-01-01', '00:00:00'),
('VN0003', 'Xe Đạp', '30A-333', 'đen', 'KV002', 'VT003', '21:52:12', '2024-08-11', '1970-01-01', '00:00:00'),
('VN35', 'Xe Đạp', 'vv123123', 'black', 'KV004', 'VT002', '23:39:53', '2024-03-25', '1970-01-01', '00:00:00'),
('VN634', 'Xe Đạp', '298129-3nmxnz', 'trắng', 'KV002', 'VT002', '21:59:47', '2024-10-06', NULL, NULL),
('VN791', 'Xe Đạp', '29V5-12311', 'đen', 'KV002', 'VT002', '07:33:39', '2024-03-26', '2024-03-26', '07:33:46'),
('VN813', 'Xe Đạp', 'vdvdv', 'vdv', 'KV003', 'VT003', '14:06:33', '2024-09-25', '1970-01-01', '00:00:00'),
('VN94', 'Xe Đạp', 'vasdf3333', 'black', 'KV002', 'VT002', '23:40:20', '2024-03-25', '1970-01-01', '00:00:00');

INSERT INTO vethang (MaVe, LoaiXe, BienSo, MauXe, TenKH, SoDienThoai, NgayDangKy, GioNhan, NgayNhan, NgayTra, GioTra, ViTri, KhuVuc)
VALUES
('VT002', 'Xe Máy', '29N1-23213', 'RED', 'Nguyen van A', '0123456678', '2024-03-22', '00:00:00', '1970-01-01', '1970-01-01', '00:00:00', NULL, NULL),
('VT003', 'Xe Máy', 'urdji2-uq21', 'white', 'duqdiudah', '0384142502', '2024-10-06', NULL, NULL, NULL, NULL, NULL, NULL),
('VT004', 'Xe Đạp', 'green', 'green', 'Ta Van Thanh', '0384142502', '2024-10-06', NULL, NULL, NULL, NULL, NULL, NULL),
('VT005', 'Xe Đạp', 'xzzxm', 'xzzxm', 'znxxzmxzm', '1234567890', '2024-10-07', NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO vitri (MaViTri, TenViTri, MaKhuVuc)
VALUES
('VT001', 'Vi Tri 1', 'KV001'),
('VT002', 'Vi Tri 2', 'KV002'),
('VT003', 'Vi Tri 3', 'KV003'),
('VT004', 'Vi Tri 4', 'KV004'),
('VT005', 'Vi Tri 5', 'KV005'),
('VT006', 'Vi Tri 6', 'KV006');
