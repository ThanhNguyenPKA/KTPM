package dao;

import entity.KhuVuc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class KhuVuc_Dao {
    private static final String URL = "jdbc:mysql://localhost:3306/qlbgx";
    private static final String USER = "root";
    private static final String PASSWORD = "!Tvt210604";

    public List<KhuVuc> getLS() {
        List<KhuVuc> ds = new ArrayList<>();
        String sql = "SELECT MaKhuVuc, TenKhuVuc FROM KhuVuc";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String ma = rs.getString("MaKhuVuc");
                String ten = rs.getString("TenKhuVuc");
                KhuVuc khuVuc = new KhuVuc(ma, ten);
                ds.add(khuVuc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return ds;
    }

    public KhuVuc TimKiemMa(String ma) {
        KhuVuc khuVuc = null;
        String sql = "SELECT TenKhuVuc FROM KhuVuc WHERE MaKhuVuc = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, ma);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String ten = rs.getString("TenKhuVuc");
                khuVuc = new KhuVuc(ma, ten);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return khuVuc;
    }

    public String TimKiemTen(String ten) {
        String maKhuVuc = null;
        String sql = "SELECT MaKhuVuc FROM KhuVuc WHERE TenKhuVuc = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, ten);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                maKhuVuc = rs.getString("MaKhuVuc");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return maKhuVuc;
    }
}
