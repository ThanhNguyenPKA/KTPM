package dao;

import entity.VeThang;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class VeThang_Dao {

    private static final String URL = "jdbc:mysql://localhost:3306/qlbgx";
    private static final String USER = "root";
    private static final String PASSWORD = "!Tvt210604";

    // Get list of VeThang
    public List<VeThang> getLS() {
    List<VeThang> veThangList = new ArrayList<>();
    try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
        String query = "SELECT * FROM VeThang"; // Điều chỉnh theo cấu trúc bảng của bạn
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
            SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");

            while (resultSet.next()) {
                String maVe = resultSet.getString("MaVe");
                String loaiXe = resultSet.getString("LoaiXe");
                String bienSo = resultSet.getString("BienSo");
                String mauXe = resultSet.getString("MauXe");
                String tenKH = resultSet.getString("TenKH");
                String soDienThoai = resultSet.getString("SoDienThoai");
                Date ngayDangKy = resultSet.getDate("NgayDangKy");

                VeThang veThang = new VeThang(maVe, loaiXe, bienSo, mauXe, tenKH, soDienThoai, ngayDangKy);
                String NgayNhan = resultSet.getString("NgayNhan");

                if (NgayNhan != null && !"null".equals(NgayNhan)) {
                    String khuVuc = resultSet.getString("KhuVuc");
                    String ViTri = resultSet.getString("ViTri");
                    String GioNhan = resultSet.getString("GioNhan");
                    String GioTra = resultSet.getString("GioTra");
                    String NgayTra = resultSet.getString("NgayTra");

                    if (GioNhan != null) {
                        Date parsedDate = dateFormat.parse(GioNhan);
                        Time gioNhan = new Time(parsedDate.getTime());
                        veThang.setGioNhan(gioNhan);
                    }

                    if (NgayNhan != null) {
                        Date parsedDate2 = dateFormat2.parse(NgayNhan);
                        veThang.setNgayNhan(parsedDate2);
                    }

                    // Set ViTri and KhuVuc nếu cần thiết, như trong triển khai trước.
                }
                veThangList.add(veThang);
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return veThangList;
}


    // Add a VeThang
    public boolean addVeThang(VeThang veThang) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "INSERT INTO VeThang (MaVe, LoaiXe, BienSo, MauXe, TenKH, SoDienThoai, NgayDangKy) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, veThang.getMaVe());
                statement.setString(2, veThang.getLoaiXe());
                statement.setString(3, veThang.getBienSo());
                statement.setString(4, veThang.getMauXe());
                statement.setString(5, veThang.getTenKH());
                statement.setString(6, veThang.getSoDienThoai());
                statement.setDate(7, new java.sql.Date(veThang.getNgayDangKy().getTime()));
                statement.executeUpdate();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update a VeThang
    public boolean updateVeThang(VeThang veThang) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "UPDATE VeThang SET LoaiXe = ?, BienSo = ?, MauXe = ?, TenKH = ?, SoDienThoai = ? WHERE MaVe = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, veThang.getLoaiXe());
                statement.setString(2, veThang.getBienSo());
                statement.setString(3, veThang.getMauXe());
                statement.setString(4, veThang.getTenKH());
                statement.setString(5, veThang.getSoDienThoai());
                statement.setString(6, veThang.getMaVe());
                statement.executeUpdate();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a VeThang
    public boolean deleteVeThang(String maVe) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "DELETE FROM VeThang WHERE MaVe = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, maVe);
                statement.executeUpdate();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateTTVeThang2(VeThang veThang) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "UPDATE VeThang SET LoaiXe = ?, BienSo = ?, MauXe = ?, TenKH = ?, SoDienThoai = ?, NgayDangKy = ? WHERE MaVe = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, veThang.getLoaiXe());
                statement.setString(2, veThang.getBienSo());
                statement.setString(3, veThang.getMauXe());
                statement.setString(4, veThang.getTenKH());
                statement.setString(5, veThang.getSoDienThoai());
                statement.setDate(6, new java.sql.Date(veThang.getNgayDangKy().getTime()));
                statement.setString(7, veThang.getMaVe());
                statement.executeUpdate();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<VeThang> TimKiemLoaiXe(String loaiXe) {
        List<VeThang> veThangList = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM VeThang WHERE LoaiXe = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, loaiXe);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        String maVe = resultSet.getString("MaVe");
                        String bienSo = resultSet.getString("BienSo");
                        String mauXe = resultSet.getString("MauXe");
                        String tenKH = resultSet.getString("TenKH");
                        String soDienThoai = resultSet.getString("SoDienThoai");
                        Date ngayDangKy = resultSet.getDate("NgayDangKy");

                        VeThang veThang = new VeThang(maVe, loaiXe, bienSo, mauXe, tenKH, soDienThoai, ngayDangKy);
                        veThangList.add(veThang);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return veThangList;
    }

    public VeThang TimKiemMa(String maVe) {
        VeThang veThang = null;
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM VeThang WHERE MaVe = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, maVe);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        String loaiXe = resultSet.getString("LoaiXe");
                        String bienSo = resultSet.getString("BienSo");
                        String mauXe = resultSet.getString("MauXe");
                        String tenKH = resultSet.getString("TenKH");
                        String soDienThoai = resultSet.getString("SoDienThoai");
                        Date ngayDangKy = resultSet.getDate("NgayDangKy");

                        veThang = new VeThang(maVe, loaiXe, bienSo, mauXe, tenKH, soDienThoai, ngayDangKy);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return veThang;
    }

    public boolean updateTTVeThang(VeThang veThang) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "UPDATE VeThang SET LoaiXe = ?, BienSo = ?, MauXe = ?, TenKH = ?, SoDienThoai = ?, NgayDangKy = ? WHERE MaVe = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, veThang.getLoaiXe());
                statement.setString(2, veThang.getBienSo());
                statement.setString(3, veThang.getMauXe());
                statement.setString(4, veThang.getTenKH());
                statement.setString(5, veThang.getSoDienThoai());
                statement.setDate(6, new java.sql.Date(veThang.getNgayDangKy().getTime()));
                statement.setString(7, veThang.getMaVe());
                statement.executeUpdate();
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public VeThang TimKiemBienSo(String bienSo) {
        VeThang veThang = null;
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM VeThang WHERE BienSo = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, bienSo);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        String maVe = resultSet.getString("MaVe");
                        String loaiXe = resultSet.getString("LoaiXe");
                        String bienSoXe = resultSet.getString("BienSo");
                        String mauXe = resultSet.getString("MauXe");
                        String tenKH = resultSet.getString("TenKH");
                        String soDienThoai = resultSet.getString("SoDienThoai");
                        Date ngayDangKy = resultSet.getDate("NgayDangKy");

                        veThang = new VeThang(maVe, loaiXe, bienSoXe, mauXe, tenKH, soDienThoai, ngayDangKy);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return veThang;
    }

    public List<VeThang> TimKiemThangDK(int thang) {
        List<VeThang> veThangList = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM VeThang WHERE MONTH(NgayDangKy) = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, thang);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        String maVe = resultSet.getString("MaVe");
                        String loaiXe = resultSet.getString("LoaiXe");
                        String bienSo = resultSet.getString("BienSo");
                        String mauXe = resultSet.getString("MauXe");
                        String tenKH = resultSet.getString("TenKH");
                        String soDienThoai = resultSet.getString("SoDienThoai");
                        Date ngayDangKy = resultSet.getDate("NgayDangKy");

                        VeThang veThang = new VeThang(maVe, loaiXe, bienSo, mauXe, tenKH, soDienThoai, ngayDangKy);
                        veThangList.add(veThang);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return veThangList;
    }

    public List<VeThang> TimKiemNgayDK(Date ngayDK) {
        List<VeThang> veThangList = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM VeThang WHERE NgayDangKy = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setDate(1, new java.sql.Date(ngayDK.getTime()));
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        String maVe = resultSet.getString("MaVe");
                        String loaiXe = resultSet.getString("LoaiXe");
                        String bienSo = resultSet.getString("BienSo");
                        String mauXe = resultSet.getString("MauXe");
                        String tenKH = resultSet.getString("TenKH");
                        String soDienThoai = resultSet.getString("SoDienThoai");
                        Date ngayDangKy = resultSet.getDate("NgayDangKy");

                        VeThang veThang = new VeThang(maVe, loaiXe, bienSo, mauXe, tenKH, soDienThoai, ngayDangKy);
                        veThangList.add(veThang);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return veThangList;
    }

    public List<VeThang> TimKiemThangGui(int thang) {
        List<VeThang> veThangList = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM VeThang WHERE MONTH(NgayNhan) = ?"; // Thay NgayGui thành NgayNhan
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, thang);
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        String maVe = resultSet.getString("MaVe");
                        String loaiXe = resultSet.getString("LoaiXe");
                        String bienSo = resultSet.getString("BienSo");
                        String mauXe = resultSet.getString("MauXe");
                        String tenKH = resultSet.getString("TenKH");
                        String soDienThoai = resultSet.getString("SoDienThoai");
                        Date ngayDangKy = resultSet.getDate("NgayDangKy");

                        VeThang veThang = new VeThang(maVe, loaiXe, bienSo, mauXe, tenKH, soDienThoai, ngayDangKy);
                        veThangList.add(veThang);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return veThangList;
    }

    public List<VeThang> TimKiemNgayGui(Date ngayNhan) {
        List<VeThang> veThangList = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM VeThang WHERE NgayNhan = ?"; // Thay NgayGui thành NgayNhan
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setDate(1, new java.sql.Date(ngayNhan.getTime()));
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        String maVe = resultSet.getString("MaVe");
                        String loaiXe = resultSet.getString("LoaiXe");
                        String bienSo = resultSet.getString("BienSo");
                        String mauXe = resultSet.getString("MauXe");
                        String tenKH = resultSet.getString("TenKH");
                        String soDienThoai = resultSet.getString("SoDienThoai");
                        Date ngayDangKy = resultSet.getDate("NgayDangKy");

                        VeThang veThang = new VeThang(maVe, loaiXe, bienSo, mauXe, tenKH, soDienThoai, ngayDangKy);
                        veThangList.add(veThang);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return veThangList;
    }
}
