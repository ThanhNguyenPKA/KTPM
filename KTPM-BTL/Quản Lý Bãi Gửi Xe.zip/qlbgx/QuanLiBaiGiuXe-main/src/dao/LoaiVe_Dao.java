package dao;

import entity.LoaiVe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LoaiVe_Dao {
    private static final String URL = "jdbc:mysql://localhost:3306/qlbgx";
    private static final String USER = "root";
    private static final String PASSWORD = "!Tvt210604";

    public List<LoaiVe> getLoaiVeList() {
        List<LoaiVe> loaiVeList = new ArrayList<>();
        String sql = "SELECT MaVe, TenVe FROM LoaiVe";  // Giả sử bảng là LoaiVe

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String maLV = rs.getString("MaVe");
                String tenLV = rs.getString("TenVe");
                LoaiVe loaiVe = new LoaiVe(maLV, tenLV);
                loaiVeList.add(loaiVe);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return loaiVeList;
    }

    public LoaiVe findLoaiVeByMa(String ma) {
        LoaiVe loaiVe = null;
        String sql = "SELECT TenVe FROM LoaiVe WHERE MaVe = ?";  // Giả sử bảng là LoaiVe

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, ma);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String tenLV = rs.getString("TenVe");
                loaiVe = new LoaiVe(ma, tenLV);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return loaiVe;
    }
}
