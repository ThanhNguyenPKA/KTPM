package dao;

import entity.KhuVuc;
import entity.ViTri;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ViTri_Dao {
    private static final String URL = "jdbc:mysql://localhost:3306/qlbgx";
    private static final String USER = "root";
    private static final String PASSWORD = "!Tvt210604";
    private KhuVuc_Dao khuVuc_dao;

    public ViTri_Dao() {
        khuVuc_dao = new KhuVuc_Dao();
    }

    public List<ViTri> getLS() {
        List<ViTri> ds = new ArrayList<>();
        String query = "SELECT * FROM ViTri";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String maViTri = rs.getString("MaViTri");
                String tenViTri = rs.getString("TenViTri");
                String maKhuVuc = rs.getString("MaKhuVuc");

                ViTri viTri = new ViTri(maViTri, tenViTri);
                viTri.setKhuVuc(khuVuc_dao.TimKiemMa(maKhuVuc));

                ds.add(viTri);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ds;
    }

    public List<ViTri> TimKiemMaKV(String ma) {
        List<ViTri> list = new ArrayList<>();
        String query = "SELECT * FROM ViTri WHERE MaKhuVuc = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, ma);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String maViTri = rs.getString("MaViTri");
                String tenViTri = rs.getString("TenViTri");
                ViTri viTri = new ViTri(maViTri, tenViTri);
                viTri.setKhuVuc(khuVuc_dao.TimKiemMa(ma));

                list.add(viTri);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public ViTri TimKiemViTriByTen(String ten) {
        ViTri viTri = null;
        String query = "SELECT * FROM ViTri WHERE TenViTri = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, ten);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String maViTri = rs.getString("MaViTri");
                String tenViTri = rs.getString("TenViTri");
                String maKhuVuc = rs.getString("MaKhuVuc");

                viTri = new ViTri(maViTri, tenViTri);
                viTri.setKhuVuc(khuVuc_dao.TimKiemMa(maKhuVuc));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return viTri;
    }

    public ViTri TimKiemViTriByMa(String ma) {
        ViTri viTri = null;
        String query = "SELECT * FROM ViTri WHERE MaViTri = ?";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, ma);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String maViTri = rs.getString("MaViTri");
                String tenViTri = rs.getString("TenViTri");
                String maKhuVuc = rs.getString("MaKhuVuc");

                viTri = new ViTri(maViTri, tenViTri);
                viTri.setKhuVuc(khuVuc_dao.TimKiemMa(maKhuVuc));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return viTri;
    }

    public void ThemViTri(ViTri viTri) {
        String query = "INSERT INTO ViTri (MaViTri, TenViTri, MaKhuVuc) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, viTri.getMaViTri());
            stmt.setString(2, viTri.getTenViTri());
            stmt.setString(3, viTri.getKhuVuc().getMaKhuVuc());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
