package dao;

import entity.VeNgay;
import entity.VeXe;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class VeXe_Dao {

    private static final String URL = "jdbc:mysql://localhost:3306/qlbgx";
    private static final String USER = "root";
    private static final String PASSWORD = "!Tvt210604";

    // Get the list of VeNgay
    public List<VeNgay> getVeNgayList() {
        List<VeNgay> veNgayList = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM VeNgay"; // Adjust based on your table structure
            try (PreparedStatement statement = connection.prepareStatement(query);
                 ResultSet resultSet = statement.executeQuery()) {

                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

                while (resultSet.next()) {
                    String maVe = resultSet.getString("MaVe");
                    String loaiXe = resultSet.getString("LoaiXe");
                    String bienSo = resultSet.getString("BienSo");
                    String mauXe = resultSet.getString("MauXe");
                    String khuVuc = resultSet.getString("KhuVuc");
                    String viTri = resultSet.getString("ViTri");
                    Time gioNhan = resultSet.getTime("GioNhan");
                    Date ngayNhan = resultSet.getDate("NgayNhan");
                    Time gioTra = resultSet.getTime("GioTra");
                    Date ngayTra = resultSet.getDate("NgayTra");

                    VeNgay veNgay = new VeNgay(maVe, loaiXe, bienSo, mauXe);
                    veNgay.setGioNhan(gioNhan);
                    veNgay.setNgayNhan(ngayNhan);
                    veNgay.setGioTra(gioTra);
                    veNgay.setNgayTra(ngayTra);
                    veNgay.setKhuVuc(new KhuVuc_Dao().TimKiemMa(khuVuc));
                    veNgay.setViTri(new ViTri_Dao().TimKiemViTriByMa(viTri));

                    veNgayList.add(veNgay);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return veNgayList;
    }

    // Add a new VeNgay
    public boolean addVeNgay(VeNgay veNgay) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "INSERT INTO VeNgay (MaVe, LoaiXe, BienSo, MauXe, KhuVuc, ViTri, GioNhan, NgayNhan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, veNgay.getMaVe());
                statement.setString(2, veNgay.getLoaiXe());
                statement.setString(3, veNgay.getBienSo());
                statement.setString(4, veNgay.getMauXe());
                statement.setString(5, veNgay.getKhuVuc().getMaKhuVuc());
                statement.setString(6, veNgay.getViTri().getMaViTri());
                statement.setTime(7, veNgay.getGioNhan());
                statement.setDate(8, new java.sql.Date(veNgay.getNgayNhan().getTime()));
                statement.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update an existing VeNgay
    public boolean updateVeNgay(VeNgay veNgay) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "UPDATE VeNgay SET LoaiXe = ?, BienSo = ?, MauXe = ?, KhuVuc = ?, ViTri = ?, GioNhan = ?, NgayNhan = ?, GioTra = ?, NgayTra = ? WHERE MaVe = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, veNgay.getLoaiXe());
                statement.setString(2, veNgay.getBienSo());
                statement.setString(3, veNgay.getMauXe());
                statement.setString(4, veNgay.getKhuVuc().getMaKhuVuc());
                statement.setString(5, veNgay.getViTri().getMaViTri());
                statement.setTime(6, veNgay.getGioNhan());
                statement.setDate(7, new java.sql.Date(veNgay.getNgayNhan().getTime()));
                statement.setTime(8, veNgay.getGioTra());
                statement.setDate(9, new java.sql.Date(veNgay.getNgayTra().getTime()));
                statement.setString(10, veNgay.getMaVe());
                statement.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a VeNgay
    public boolean deleteVeNgay(String maVe) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "DELETE FROM VeNgay WHERE MaVe = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, maVe);
                statement.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Search VeNgay by license plate
    public VeNgay TimKiemBienSo(String bienSo) {
        for (VeNgay veNgay : getVeNgayList()) {
            if (veNgay.getBienSo().contains(bienSo)) {
                return veNgay;
            }
        }
        return null;
    }

    // Search VeNgay by code
    public VeNgay TimKiemMa(String ma) {
        for (VeNgay veNgay : getVeNgayList()) {
            if (veNgay.getMaVe().equals(ma)) {
                return veNgay;
            }
        }
        return null;
    }

    // Search by vehicle type
    public List<VeNgay> TimKiemLoaiXe(String loaiXe) {
        List<VeNgay> list = new ArrayList<>();
        for (VeNgay veNgay : getVeNgayList()) {
            if (veNgay.getLoaiXe().equalsIgnoreCase(loaiXe)) {
                list.add(veNgay);
            }
        }
        return list;
    }

    // Search by month
    public List<VeNgay> TimKiemThang(int thang) {
        List<VeNgay> list = new ArrayList<>();
        for (VeNgay veNgay : getVeNgayList()) {
            if (veNgay.getNgayNhan().getMonth() + 1 == thang) {
                list.add(veNgay);
            }
        }
        return list;
    }

    // Private method to find VeNgay by MaVe
    private VeNgay findVeNgayByMaVe(String maVe) {
        for (VeNgay veNgay : getVeNgayList()) {
            if (veNgay.getMaVe().equals(maVe)) {
                return veNgay;
            }
        }
        return null;
    }

    public List<VeNgay> TimKiemNgay(Date ngay) {
        List<VeNgay> veNgayList = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM VeNgay WHERE NgayNhan = ?";  // Truy vấn dựa trên NgayNhan
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setDate(1, new java.sql.Date(ngay.getTime()));  // Sử dụng NgayNhan từ tham số
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        // Lấy dữ liệu từ kết quả truy vấn
                        String maVe = resultSet.getString("MaVe");
                        String loaiXe = resultSet.getString("LoaiXe");
                        String bienSo = resultSet.getString("BienSo");
                        String mauXe = resultSet.getString("MauXe");
                        String khuVuc = resultSet.getString("KhuVuc");
                        String viTri = resultSet.getString("ViTri");
                        Time gioNhan = resultSet.getTime("GioNhan");
                        Date ngayNhan = resultSet.getDate("NgayNhan");
                        Date ngayTra = resultSet.getDate("NgayTra");
                        Time gioTra = resultSet.getTime("GioTra");

                        // Tạo đối tượng VeNgay và thêm vào danh sách
                        VeNgay veNgay = new VeNgay(maVe, loaiXe, bienSo, mauXe, khuVuc, viTri, gioNhan, ngayNhan, ngayTra, gioTra);
                        veNgayList.add(veNgay);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return veNgayList;
    }
}
