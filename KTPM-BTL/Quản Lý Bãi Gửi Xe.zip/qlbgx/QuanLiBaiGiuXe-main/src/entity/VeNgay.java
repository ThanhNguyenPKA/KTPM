package entity;

import java.sql.Date;
import java.sql.Time;

public class VeNgay extends VeXe {

    public VeNgay(String maVe, String loaiXe, String bienSo, String mauXe) {
        super(maVe, loaiXe, bienSo, mauXe);
    }
    
    

    public VeNgay() {
    }

    public VeNgay(String maVe, String loaiXe, String bienSo, String mauXe, String khuVuc, String viTri, Time gioNhan, java.util.Date ngayNhan, java.util.Date ngayTra, Time gioTra) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
