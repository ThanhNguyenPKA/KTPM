package application;

import ui.Form_GiaoDienChinh;
import ui.FormDangNhap;

public class RunApplication {
    public static void main(String[] args) {
        new FormDangNhap().setVisible(true);
//        new Form_GiaoDienChinh().setVisible(true);
    }
}
